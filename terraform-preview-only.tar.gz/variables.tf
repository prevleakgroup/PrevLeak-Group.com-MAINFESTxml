variable "billing_account" {
  description = "The ID of the billing account to associate projects with"
  type        = string
  default     = "01B909-5A70E4-F9B718"
}

variable "org_id" {
  description = "The organization id for the associated resources"
  type        = string
  default     = "248546701919"
}

variable "billing_project" {
  description = "The project id to use for billing"
  type        = string
  default     = "cs-host-816ae34bf9284593b7b924"
}

variable "folders" {
  description = "Folder structure as a map"
  type        = map
}

variable "application_enabled_folder_paths" {
  description = "The folder paths to enable resource manager capability"
  type        = list
}

variable "cmek_autokey_folders" {
  description = "Folders for CMEK autokey encryption"
  type        = list
}
